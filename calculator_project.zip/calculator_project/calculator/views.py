import csv
from django.shortcuts import render
from django.conf import settings
import os

# Create your views here.




def save_to_csv(num1, num2, operation, result):
    # Define the file path
    file_path = os.path.join(settings.BASE_DIR, "calculations.csv")
    
    # Check if the file exists
    file_exists = os.path.isfile(file_path)

    # Open the file in append mode
    with open(file_path, mode="a", newline="") as file:
        writer = csv.writer(file)
        # If the file is new, write the header
        if not file_exists:
            writer.writerow(["Number 1", "Number 2", "Operation", "Result"])
        # Write the data
        writer.writerow([num1, num2, operation, result])







def home(request):
    result = None
    if request.method == "POST":
        num1 = float(request.POST.get("num1", 0))
        num2 = float(request.POST.get("num2", 0))
        operation = request.POST.get("operation")

        if operation == "add":
            result = num1 + num2
        elif operation == "subtract":
            result = num1 - num2
        elif operation == "multiply":
            result = num1 * num2
        elif operation == "divide":
            result = num1 / num2 if num2 != 0 else "Cannot divide by zero"
        if result is not None:
            save_to_csv(num1, num2, operation, result)

    return render(request, "calculator/home.html", {"result": result})


